const webpackConfig = require("./webpack/config");

module.exports = (env, arg) => webpackConfig(env, arg);
