<?php
namespace NewsPress\Revisions;

if ( ! defined( 'NEWSPRESS_REVISIONS_DIR' ) ) {
	define( 'NEWSPRESS_REVISIONS_DIR', rtrim( \dirname( __FILE__, 2 ), '/' ) );
}
