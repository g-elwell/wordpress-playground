<?php // phpcs:ignore ?>
<div
	id="revisions-view"
>
	<div class="revisions">
		<div class="revisions-message">
			<p>Loading...</p>
		</div>
	</div>
</div>
